let textos_ES={

    // mensajes BACK
    // ---------------------------------
    'SQL_OK':'', // action realizada con exito
    'SQL_KO':'', // action falla en la operacion en la bd
    //'ATRIBUTO_es_nulo_KO':'', significa que un atributo necesario no se ha enviado
    'dni_es_nulo_KO':'No se ha enviado el dni',
    //'ERROR_UPLOAD_ATRIBUTO_KO':'', significa que un atributo de tipo file no cumple condiciones de extension o tamaño, viene descrito en el resource
    'controlador_invalido':'', // no se envia la entidad
    'action_invalido':'', // no se envia la accion

   

};

