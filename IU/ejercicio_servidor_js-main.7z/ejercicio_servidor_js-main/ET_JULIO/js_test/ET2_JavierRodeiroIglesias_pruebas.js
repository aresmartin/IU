var pruebasunitarias = Array(
    Array('1','personas','nombre_persona','1','aa',false),
    Array('1','personas','nombre_persona','2','aaaaaaa',true),
    Array('1','personas','nombre_persona','3','aaaaaaa',false),
    Array('2','personas','nombre_persona','4','aa'.repeat(100),false),
    Array('2','personas','nombre_persona','5','aaaaaaa',true),
    Array('2','personas','nombre_persona','6','aa'.repeat(100),true),
    Array('2','publicacion','nombre_publicacion','7','aa'.repeat(100),true),
);