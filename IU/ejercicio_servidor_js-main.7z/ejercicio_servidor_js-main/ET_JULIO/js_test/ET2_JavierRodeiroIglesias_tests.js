var def_test = Array(
    Array('personas','nombre_persona','1','tamaño < 6',false,'tamaño minino incorrecto'),
    Array('personas','nombre_persona','2','tamaño > 50',false,'tamaño maximo incorrecto')
);