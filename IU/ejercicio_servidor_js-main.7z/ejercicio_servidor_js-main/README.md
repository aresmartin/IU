# ejercicio_servidor_js

### Se sustituyen las funciones createForm_ADD(), createForm_EDIT(), etc. por una funció genérica createForm() que vaya construyendo las ventanas emergentes de cada funcionalidad de forma dinámica. Además, dentro de esta función createForm() lo primero que se hace es llamar a una función FormBase() que genera una plantilla del formulario que aparece en esas ventanas emergentes de las funcionalidades. Estas 2 funciones se declaran en la clase padre GestionEntidad.js y se implementan en la clase hija GestionPersona.js. Observa que he sustituido estas declaraciones e implementaciones por las de estas 2 nuevas funciones (he dejado el código de las funciones antiguas comentado para que puedas comparar y entender lo que hice).
### Implementadas las funcionalidades de ADD y SEARCH.
### En lo primero quete tienes que fijar es en las líneas 17 y 18 de la Clase GestionEntidad porque es ahí donde está la llamada a las funciones createForm_ADD() y createForm_SEARCH(). Cmo ahora vamos a sustituir estas 2 funciones estáticas por 1 dinámica lo que hice fue llamar a la función createForm() introduciendo por parámetro la estructura y la etiqueta "ADD" o "SEARCH" para que la función sepa donde buscar dentro de la estructura.
### A continuación paso a la edición de la función única como te expliqué el otro día. Las funciones de las validaciones han quedado más o menos como estaban porque no hubo forma de reciclarlas (seguiré dándole una vuelta a este tema). Lo que sí cambié es que en vez de hardcodear en ellas los dato concretos de validación, les metí la estructura por parámetro para que tomen de ahí los datos tal y como te expliqué el otro día.
### Observa que en la función createForm() he dividido con un if-else para ADD y para SEARCH porque no tienen los mismos campos en el formulario.

## Próximos pasos:

### Hacer esto mismo para las funcionalidades EDIT, DELETE y SHOWCURRENT.
### Para ello primero fíjate en las líneas 105 y 106 del archivo GestionEntidad.js porque ahí es donde se llama dinámicamente a las funciones de createForm_EDIT(), createForm_DELETE() y createForm_SHOWCURRENT(). Te dejé comentada la línea antigua y te puse la nueva para que compares. Básicamente es quitarle la variable accion que es la que lleva la etiqueta "EDIT", "DELETE" o "SHOWCURRENT".
### Examina los campos que tienen estas funcionalidades en los formularios a ver si tienes que crear más else if en la función createForm() genérica o si puedes aprovechar alguna condición para varias funcionalidades.
### Debes ir adaptando la estructura a medida que vayas avanzando. Por ejemplo, el SHOWCURRENT no está incluido, ese lo tiene que añadir completo.

# ¡¡¡¡¡¡ADVERTENCIAS!!!!!!

### 1. Este código se ha hecho directamente desde ET2, no desde tu ET_JULIO aunque el directorio se llame ET_JULIO, así que lo que te recomiendo es que vayas cortando y pegando código de este al tuyo porque a este le falta todo lo que hiciste en APP.html y lo de tus datos personales con JS. Además, en este te he dejado algún comentario en código.
### 2. Una vez hayas terminado de configurar persona, le pasamos los test ya que partimos de una plantilla de código que sabemos que funciona y después hacer programa y publicación no va a ser más que copiar y pegar cambiando nomenclatura.
